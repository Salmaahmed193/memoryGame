// Game  variables
var openedcard = [];
var openedtmpcard = [];
var matchedCards = 0;
var playerMoves = 0;
var clicked = 0;
var Stars = 3;
var timer = {
    seconds: 0,
    minutes: 0,
    hours: 0,
    stopTime: -1
};


// list that holds all of your cards
var CardsList = ["fa fa-diamond", "fa fa-diamond", "fa fa-paper-plane-o", "fa fa-paper-plane-o", "fa fa-anchor", "fa fa-anchor",
    "fa fa-bolt", "fa fa-bolt", "fa fa-cube", "fa fa-cube", "fa fa-leaf", "fa fa-leaf",
    "fa fa-bicycle", "fa fa-bicycle", "fa fa-bomb", "fa fa-bomb"
];

/*
 * shuffle() function provided by Udacity's starter code
 */
function shuffle(array) {
    var currentIndex = array.length,
        temporaryValue, randomIndex;

    while (currentIndex !== 0) {
        randomIndex = Math.floor(Math.random() * currentIndex);
        currentIndex -= 1;
        temporaryValue = array[currentIndex];
        array[currentIndex] = array[randomIndex];
        array[randomIndex] = temporaryValue;
    }

    return array;
};

// displayed timer When the player starts a game
var startTimerinterval = function() {
    if (clicked > 0)
        timer.seconds++;
    if (timer.seconds === 59) {
        timer.minutes++;
        timer.seconds = 0;
    }
    if (timer.minutes === 60) {
        timer.hours++;
        timer.minutes = 0;
        timer.seconds = 0;
    }

    $('.timer').html(timer.hours + ':' + timer.minutes + ':' + timer.seconds);

};

//reset time  to default
function resetTimer() {
    clearInterval(timer.stopTime);
    timer.seconds = 0;
    timer.minutes = 0;
    timer.hours = 0;
    $('.timer').html('0:0:0');
    timer.stopTime = setInterval(startTimerinterval, 1000);
};


//shuffle the list of cards using the provided "shuffle" method 
function generateRandomCards() {
    CardsList = shuffle(CardsList);
    let index = 0;
    $.each($(".card i"), function() {
        $(this).attr("class", CardsList[index]);
        $(this).attr("id", index);
        index++;
    });
    resetTimer();
};


function Displaywinner() {
    $("#win-modal").css("display", "block");
};

// Removes last start from remaining stars
function callremoveStar() {
    $(".fa-star").last().attr("class", "fa fa-star-o");
    Stars--;
    $(".num-stars").text(String(Stars));

};


//  At the beginning of a game or when reser game stars value display 3 stars
function DefultStars() {
    Stars = 3;
    $('.stars i').removeClass('fa-star-o')
    $(".stars i").addClass("fa-star");
    $(".num-stars").text(String(Stars));
};

// Updates number of moves and  removes stars specific  based on numbers of movments 
function updateStarsandMoves() {
    $(".moves").text(playerMoves);

    if (playerMoves === 5 || playerMoves === 25) {
        callremoveStar();
    }
};

//check if  user clicks on two different unmatched cards.to incerement movement
function incrementNumMoves() {
    if (openedtmpcard.length > 2) {
        if (openedtmpcard[0].find('i').attr('id') === openedcard[0].find('i').attr('id') &&
            openedtmpcard[1].find('i').attr('id') === openedcard[1].find('i').attr('id')) {
            return true;
        } else {
            var len = openedtmpcard.length - 2;
            openedtmpcard.splice(0, len);
            return false;
        }
    } else {
        return false;
    }
};

//check to see if the two cards match
function matchCards() {
    if (openedcard[0].find('i').attr('class') === openedcard[1].find('i').attr('class')) {
        return true;
    } else {
        return false;
    }
};


// check if player win game
function WinGame() {
    if (matchedCards === 16) {
        return true;
    } else {
        return false;
    }
};

//  if the cards do match, lock the cards in the open position 
var setCardMatched = function() {
    openedcard.forEach(function(card) {
        card.addClass("match");
        // card.addClass('animated wobble');
    });
    openedcard = [];
    openedtmpcard = [];
    matchedCards += 2;
    // cal win function to check if win
    if (WinGame()) {
        clearInterval(timer.stopTime);
        Displaywinner();
    }
};

//if the cards do not match, add style class then reset to open cards
var Mismatched = function() {
    openedcard.forEach(function(card) {
        card.addClass('animated rubberBand');
    });

};

var resetOpen = function() {
    openedcard.forEach(function(card) {
        card.toggleClass("open show");
    });
    openedcard = [];
};

//add the card to a *list* of "open" cards
function openCard(card) {
    if (!card.hasClass("open")) {
        card.toggleClass("open show");
        openedtmpcard.push(card);
        openedcard.push(card);

    }
};

// Resets all game state variables and resets all  HTML to default state
function resetCards() {
    $(".card").attr("class", "card");
};


var resetGame = function() {
    openedcard = [];
    openedtmpcard = [];
    matchedCards = 0;
    playerMoves = 0;
    clicked = 0;
    resetTimer();
    DefultStars();
    updateStarsandMoves();
    resetCards();
    generateRandomCards();

};


// set up the event listener for a card. If a card is clicked
var onClickcard = function() {


    if (!$(this).hasClass("open") || !$(this).hasClass("match")) {

        if (openedcard.length === 0) {
            openCard($(this));
            clicked = +1;

        } else if (openedcard.length === 1) {
            openCard($(this));
            if (openedcard[0].find('i').attr('id') != openedcard[1].find('i').attr('id')) {

                playerMoves++;
                if (playerMoves >= 2) {
                    if (incrementNumMoves() == true) {
                        playerMoves--;
                        updateStarsandMoves();
                    }
                }
                updateStarsandMoves();
            }
        }

        if (matchCards()) {
            setTimeout(setCardMatched, 300);

        } else {
            setTimeout(function() {
                Mismatched() // runs first
                resetOpen() // runs second
            }, 600)


        }

    }
};

// Resets game state and  display off winner mood
var playAgain = function() {
    resetGame();
    $("#win-modal").css("display", "none");
};

/*
 * Initalize event listeners
 */

$(".card").click(onClickcard);
$(".restart").click(resetGame);
$(".play-again").click(playAgain);

// generate  random cards on page load
$(document).ready(generateRandomCards);