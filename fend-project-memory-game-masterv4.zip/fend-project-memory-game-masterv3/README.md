# Memory Game Project
by Salma Ahmed

## Table of Contents

* [Description](#description)
* [Instructions](#Instructions)
* [Resources](#Resources)
* [How to Play](#How_to_Play)
* [What to expect](#What_to_expect)


## Description
This is a card matching game that contains 8 pairs of cards, you win if you match all pairs . Your Movemets and time are displayed in upper of the page including your stars and it depends on the amount of moves it took you to win the game.


## Instructions

To play the game download the contents of the repository and open `index.html` in your browser.


## Resources
project developed using HTMl, CSS, JavaScript and jQuery in addition to 
* Font Awesome: [https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css)
* Jquery: [http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js]
* mdbootstrap: [https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.3.2/css/mdb.min.css]

## How to Play

* Click a card to open it, if two opened cards matches, they will keep opening. 
* Mismatched cards will be turned over, and the user must select a new pair of cards.
* Once all 8 pairs are matched, the user win the game (and can play again)
* The player is given a score of 1 star to 3 stars depending on how many moves are made to win 	 the game .
* Time is kept from when the user makes his first selection
* finaly when all cards matches, you win.

## What the player is to expect from the game.
 *Try to win the game with less moves and you will get more stars. 
 *this game helps you to activate your memory 